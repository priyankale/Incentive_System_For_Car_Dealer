import React, { Component } from 'react';
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import CarCompanyService from '../services/CarCompanyService'

import "./Login.css";


export class CompanyLogin extends Component {
    state = {
        username: "",
        password: "",
        companyLogin: [],
        loggedIn: '',
        alreadyLogged: ''
    }
    onInputChange = (e) => {
        this.setState({
            [e.target.name]: [e.target.value]
        })
        // console.log(this.state.email,this.state.password)
    }
    componentDidMount() {
        CarCompanyService.getCompanys().then((res) => {
            this.setState({ companyLogin: res.data });

        });
        // console.log(811,this.state.dealerLogin)

    }

    onSubmitHandler = (e) => {
        e.preventDefault();
        this.state.companyLogin.map((data) => {
            if (this.state.username[0] === data.cMail && this.state.password[0] === data.password) {
                this.setState({
                    loggedIn: this.state.username[0]
                })
                localStorage.setItem('userNm', this.state.username[0])
                var user1 = localStorage.getItem('userNm');
                // var msg = new SpeechSynthesisUtterance(`Hello${user1}........Welcome in Song Pro...Now click on the Mic and tell me what you want to watch today`);
                //   msg.volume = 1;
                //   msg.rate = 1;
                //   msg.pitch = 0.8;
                //   msg.lang = 'en-US';
                //   window.speechSynthesis.speak(msg);
               var notify =new Notification(`${this.state.username[0]} is successfully logged in....`)
               //setTimeout(() => {
                    window.location.href = '/companyhome'
               // }, 2000);
            }
            else{
                setTimeout(() => {
                    document.querySelector('#loginerrorid').classList.add('error-show')
                    document.querySelector('#loginerrorid').classList.remove('error-hide')


                }, 2000);
               // document.querySelector('#loginerrorid').style.display='block'
            }
        })





        //         console.log(888, data.password, this.state.password[0], data.mail, this.state.email[0])
        //         if (data.mail === this.state.email[0]) {
        //             if (data.password === this.state.password[0]) {
        //                 this.setState({
        //                     isLoggedIn: true
        //                 })
        //                 localStorage.setItem('user',this.state.email)
        //                 console.log(this.state.isLoggedIn, "login successfully")
        //             }

        //         }
        //   })
        //  var userAuth= localStorage.getItem('user')
        //   console.log(121, localStorage.getItem('user') )
        //      if(userAuth === this.state.email){
        //         window.location.href = '/home'

        //     }

        //     else{
        //         console.log(812, this.state.isLoggedIn)

        //         alert("Invalid Email or Password")
        // }

        // console.log(911, this.state.isLoggedIn)

        // console.log(922, this.state.dealerLogin)


    }

    render() {

        return (
            <div className="Login">
                <h1 align="center">
          <span className="badge badge-dark" >Welcome to Company Login Page</span>
        </h1>
                 {/* <h1 align="center"><strong>Welcome to Company Login Page</strong></h1> */}
                <Form onSubmit={this.onSubmitHandler} className="form-style">
                    <Form.Group size="lg" controlId="username">
                        <Form.Label style={{color:'white'}}> Company Email</Form.Label>
                        <Form.Control
                            autoFocus
                            type="username"
                            name="username"
                            value={this.state.username}
                            onChange={this.onInputChange}
                        />
                    </Form.Group>
                    <Form.Group size="lg" controlId="password">
                        <Form.Label style={{color:'white'}}>Password</Form.Label>
                        <Form.Control
                            type="password"
                            name="password"
                            value={this.state.password}
                            onChange={this.onInputChange}
                        />
                    </Form.Group>
                    <div className="error-hide" id="loginerrorid">Invalid email or password</div>
                    <Button block size="lg" type="submit">
                        Login
                </Button>
                </Form>
            </div>
        );
    }
}

export default CompanyLogin
